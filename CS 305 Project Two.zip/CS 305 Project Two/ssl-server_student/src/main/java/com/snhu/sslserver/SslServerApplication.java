package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HexFormat;

@SpringBootApplication
@RestController
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    private static final String STUDENT_NAME = "Malaki Guenther";  // ←←← CHANGE THIS LINE

    @GetMapping(value = "/hash", produces = "text/html")
    public String showChecksum() {
        try {
            // Create unique data string with name and current timestamp
            String timestamp = LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
            String data = STUDENT_NAME + " - " + timestamp;

            // Calculate SHA-256 hash
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(data.getBytes("UTF-8"));
            String checksum = HexFormat.of().formatHex(digest);
            
         // Build HTML response the old-school way (Java 11 compatible)
            StringBuilder html = new StringBuilder();
            html.append("<!DOCTYPE html>\n");
            html.append("<html>\n");
            html.append("<head>\n");
            html.append("    <title>Artemis Financial - Secure Hash Server</title>\n");
            html.append("    <style>\n");
            html.append("        body {font-family: Arial, sans-serif; text-align: center; margin-top: 60px; background: #f8f9fa;}\n");
            html.append("        .container {max-width: 800px; margin: 0 auto; padding: 30px; background: white; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);}\n");
            html.append("        h1 {color: #1a5276;}\n");
            html.append("        .info {font-size: 18px; margin: 20px 0;}\n");
            html.append("        .checksum {font-family: monospace; background: #f0f0f0; padding: 15px; border-radius: 8px; word-wrap: break-word;}\n");
            html.append("    </style>\n");
            html.append("</head>\n");
            html.append("<body>\n");
            html.append("    <div class=\"container\">\n");
            html.append("        <h1>Artemis Financial<br>Secure Communication & Data Integrity Check</h1>\n");
            html.append("		 <div class=\"info\">\n");
            html.append("            <p><strong>Name:</strong> " + STUDENT_NAME + "</p>\n");
            html.append("            <p><strong>Timestamp:</strong> " + timestamp + "</p>\n");
            html.append("            <p><strong>Algorithm:</strong> SHA-256</p>\n");
            html.append("        </div>\n");
            html.append("        <p><strong>Generated Checksum:</strong></p>\n");
            html.append("        <div class=\"checksum\">" + checksum + "</div>\n");
            html.append("        <hr style=\"margin: 40px 0;\">\n");
            html.append("        <p><strong>Recommended Cipher Suite:</strong> AES-256-GCM</p>\n");
            html.append("        <p>Connection secured with HTTPS and self-signed certificate</p>\n");
            html.append("    </div>\n");
            html.append("</body>\n");
            html.append("</html>");

            return html.toString();
        } catch (Exception e) {
            return "<h2>Error generating checksum: " + e.getMessage() + "</h2>";
        }
    }
}