package com.snhu.sslserver;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * CS-305 Artemis Financial - Secure Server JUnit 5 Tests
 * Author: Malaki Guenther
 * Tests the /hash endpoint for functionality, correct content, and SHA-256 output
 */
@SpringBootTest
@AutoConfigureMockMvc
class SslServerApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("GET /hash returns 200 OK and contains student name")
    void testHashEndpointReturnsSuccessAndContainsName() throws Exception {
        mockMvc.perform(get("/hash")
                .accept(MediaType.TEXT_HTML))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Malaki Guenther")));
    }

    @Test
    @DisplayName("GET /hash returns page with current timestamp")
    void testHashEndpointContainsTimestamp() throws Exception {
        mockMvc.perform(get("/hash"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("2025"))); // Year will always be 2025 or later
    }

    @Test
    @DisplayName("GET /hash returns a valid 64-character SHA-256 checksum")
    void testHashEndpointReturnsValidSHA256Checksum() throws Exception {
        mockMvc.perform(get("/hash"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Generated Checksum:")))
                .andExpect(content().string(org.hamcrest.Matchers.matchesRegex(".*[a-f0-9]{64}.*"))); // Exactly 64 hex chars
    }

    @Test
    @DisplayName("GET /hash mentions recommended cipher suite AES-256-GCM")
    void testHashEndpointMentionsRecommendedCipher() throws Exception {
        mockMvc.perform(get("/hash"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("AES-256-GCM")));
    }

    @Test
    @DisplayName("Page title is correct")
    void testPageHasCorrectTitle() throws Exception {
        mockMvc.perform(get("/hash"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Artemis Financial - Secure Hash Server")));
    }
}